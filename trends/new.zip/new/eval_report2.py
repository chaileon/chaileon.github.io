#!/usr/bin/env python3
"""Aggregate think/nothink v2 results and emit eval_report2.json + console table."""
import json
from collections import defaultdict

MODELS = [
    "qwen/qwen3.5-plus-20260420", "qwen/qwen3.5-plus-02-15", "qwen/qwen3.5-flash-02-23",
    "qwen/qwen3.5-9b", "qwen/qwen3.5-27b", "qwen/qwen3.5-35b-a3b",
    "qwen/qwen3.5-122b-a10b", "qwen/qwen3.5-397b-a17b",
    "z-ai/glm-5.2", "anthropic/claude-opus-4.8",
]
MODES = ["think", "nothink"]

qa = json.load(open("QA_06072026.json"))
answers = json.load(open("answers_v2.json"))
judged = json.load(open("judgements_v2.json"))

def key(m, mode, qid): return f"{m}||{mode}||{qid}"

stats = {m: {mode: {"correct": 0, "partial": 0, "incorrect": 0, "n": 0, "score": 0.0, "rtok": 0}
             for mode in MODES} for m in MODELS}

for q in qa:
    qid = q["question_id"]
    for m in MODELS:
        for mode in MODES:
            k = key(m, mode, qid)
            a = answers.get(k, {}) or {}
            j = judged.get(k, {}) or {}
            v = j.get("verdict") if j.get("ok") else None
            st = stats[m][mode]
            st["n"] += 1
            st["score"] += (j.get("score", 0.0) if j.get("ok") else 0.0)
            st["rtok"] += a.get("reasoning_tokens", 0) or 0
            if v == "correct": st["correct"] += 1
            elif v == "partially_correct": st["partial"] += 1
            else: st["incorrect"] += 1

print(f"\n{'model':28} {'think acc':>10} {'nothink acc':>12} {'delta':>7} {'think_rtok':>11}")
for m in MODELS:
    t, n = stats[m]["think"], stats[m]["nothink"]
    ta = t["correct"]/t["n"]*100 if t["n"] else 0
    na = n["correct"]/n["n"]*100 if n["n"] else 0
    rt = t["rtok"]/t["n"] if t["n"] else 0
    print(f"{m.split('/')[-1]:28} {ta:9.1f}% {na:11.1f}% {ta-na:+6.1f} {rt:11.0f}")

# Build report json
def cell(m, mode, qid):
    a = answers.get(key(m, mode, qid), {}) or {}
    j = judged.get(key(m, mode, qid), {}) or {}
    return {
        "verdict": j.get("verdict", "error") if j.get("ok") else "error",
        "score": j.get("score", 0.0) if j.get("ok") else 0.0,
        "reason": j.get("reason", ""), "extracted": j.get("extracted_answer", ""),
        "answer": a.get("content", ""), "reasoning": a.get("reasoning", ""),
        "reasoning_tokens": a.get("reasoning_tokens", 0) or 0,
    }

report = {
    "models": MODELS, "modes": MODES, "stats": stats,
    "questions": [{
        "qid": q["question_id"], "category": q["question_category"], "sample_id": q["sample_id"],
        "question": q["question"], "short_answer": q["short_answer"], "answer": q["answer"],
        "remarks": q.get("remarks"), "necessary_articles": q["necessary_articles"],
        "modified_articles": q["modified_articles"],
        "results": {m: {mode: cell(m, mode, q["question_id"]) for mode in MODES} for m in MODELS},
    } for q in qa],
}
json.dump(report, open("eval_report2.json", "w"), ensure_ascii=False)
print("\nWrote eval_report2.json")
