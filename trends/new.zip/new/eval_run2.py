#!/usr/bin/env python3
"""Run all 10 models in THINK and NOTHINK mode, capturing reasoning traces. Resumable."""
import os, json, time, urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor, as_completed

KEY = os.environ["OPENROUTERS_API_KEY"]
URL = "https://openrouter.ai/api/v1/chat/completions"
OUT = "answers_v2.json"

MODELS = [
    "qwen/qwen3.5-plus-20260420", "qwen/qwen3.5-plus-02-15", "qwen/qwen3.5-flash-02-23",
    "qwen/qwen3.5-9b", "qwen/qwen3.5-27b", "qwen/qwen3.5-35b-a3b",
    "qwen/qwen3.5-122b-a10b", "qwen/qwen3.5-397b-a17b",
    "z-ai/glm-5.2", "anthropic/claude-opus-4.8",
]
MODES = ["think", "nothink"]

qa = json.load(open("QA_06072026.json"))
samples = {str(x["article_id"]): x for x in json.load(open("samples_06072026.json"))}
modified = json.load(open("modified_articles_06072026.json"))
mod_by_id = {m["modified_article_id"]: m for m in modified}

def parse_list(v):
    return [s.strip() for s in str(v).split(",") if s.strip()] if v else []

def build_context(q):
    nec = parse_list(q["necessary_articles"])
    mods = set(parse_list(q["modified_articles"]))
    mod_aids = {str(mod_by_id[m]["article_id"]): m for m in mods if m in mod_by_id}
    blocks = []
    for aid in nec:
        a = samples.get(aid)
        if aid in mod_aids:
            text = mod_by_id[mod_aids[aid]]["modified_text"]
        else:
            text = a["full_text"] if a else "(article text unavailable)"
        title = (a and a["article_title"]) or f"Article {aid}"
        meta = " | ".join(x for x in [title, (a and a.get("source")) or "", (a and a.get("publication_date")) or ""] if x)
        blocks.append(f"===== ARTICLE {aid}: {meta} =====\n{text}")
    return "\n\n".join(blocks)

SYSTEM = (
    "You are a careful analyst. You are given one or more news articles and a question. "
    "Answer the question using ONLY the information in the provided articles. Reason step by step. "
    "Then, on the final line, output your definitive answer in the exact form:\nFINAL ANSWER: <your concise answer>"
)

def make_prompt(q):
    return (f"{build_context(q)}\n\n====================\n"
            f"QUESTION ({q['question_category']}): {q['question']}\n\n"
            f"Answer using only the articles above. End with a line 'FINAL ANSWER: ...'.")

def call_model(model, mode, prompt, retries=4):
    is_anthropic = model.startswith("anthropic/")
    if mode == "think":
        reasoning = {"enabled": True}
        temperature = 1 if is_anthropic else 0
        max_tokens = 22000
    else:
        reasoning = {"enabled": False}
        temperature = 0
        max_tokens = 4000
    body = json.dumps({
        "model": model, "messages": [
            {"role": "system", "content": SYSTEM}, {"role": "user", "content": prompt}],
        "temperature": temperature, "max_tokens": max_tokens, "reasoning": reasoning,
    }).encode()
    last = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(URL, body, {
                "Authorization": f"Bearer {KEY}", "Content-Type": "application/json",
                "HTTP-Referer": "https://localhost/qa-eval", "X-Title": "QA Eval v2"})
            with urllib.request.urlopen(req, timeout=360) as r:
                d = json.load(r)
            if "choices" not in d:
                last = f"no choices: {json.dumps(d)[:300]}"; time.sleep(2**attempt); continue
            msg = d["choices"][0]["message"]
            usage = d.get("usage", {}) or {}
            ctd = usage.get("completion_tokens_details") or {}
            return {"ok": True, "content": msg.get("content") or "",
                    "reasoning": msg.get("reasoning") or "",
                    "reasoning_tokens": ctd.get("reasoning_tokens", 0) or 0,
                    "finish_reason": d["choices"][0].get("finish_reason"),
                    "served_model": d.get("model"), "usage": usage}
        except urllib.error.HTTPError as e:
            last = f"HTTP {e.code}: {e.read().decode(errors='replace')[:250]}"
            if e.code in (429, 500, 502, 503, 520, 524): time.sleep(2**attempt + 1); continue
            break
        except Exception as e:
            last = f"{type(e).__name__}: {e}"; time.sleep(2**attempt + 1)
    return {"ok": False, "error": last}

def key(m, mode, qid): return f"{m}||{mode}||{qid}"

def main():
    results = json.load(open(OUT)) if os.path.exists(OUT) else {}
    prompts = {q["question_id"]: make_prompt(q) for q in qa}
    tasks = []
    for q in qa:
        for m in MODELS:
            for mode in MODES:
                k = key(m, mode, q["question_id"])
                if k in results and results[k].get("ok"): continue
                tasks.append((m, mode, q["question_id"], prompts[q["question_id"]]))
    print(f"Pending: {len(tasks)} (done: {sum(1 for v in results.values() if v.get('ok'))})")

    done = [0]; last_save = [time.time()]
    def run(t):
        m, mode, qid, prompt = t
        res = call_model(m, mode, prompt)
        res.update({"model": m, "mode": mode, "question_id": qid})
        return key(m, mode, qid), res
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = [ex.submit(run, t) for t in tasks]
        for fut in as_completed(futs):
            k, res = fut.result(); results[k] = res; done[0] += 1
            m, mode, qid = k.split("||")
            tag = "ok" if res.get("ok") else f"FAIL {str(res.get('error'))[:50]}"
            rt = res.get("reasoning_tokens", 0)
            print(f"[{done[0]}/{len(tasks)}] {m.split('/')[-1]:26} {mode:7} Q{qid:>2} rt={rt:<6} {tag}")
            if time.time() - last_save[0] > 5 or done[0] == len(tasks):
                json.dump(results, open(OUT, "w"), ensure_ascii=False); last_save[0] = time.time()
    json.dump(results, open(OUT, "w"), ensure_ascii=False)
    ok = sum(1 for v in results.values() if v.get("ok"))
    print(f"\nDone. ok={ok} fail={len(results)-ok} total={len(results)}")

if __name__ == "__main__":
    main()
