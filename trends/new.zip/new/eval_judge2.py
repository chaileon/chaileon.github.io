#!/usr/bin/env python3
"""Judge v2 answers (think/nothink) with gpt-4o. Resumable."""
import os, json, time, re, urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor, as_completed

KEY = os.environ["OPENROUTERS_API_KEY"]
URL = "https://openrouter.ai/api/v1/chat/completions"
JUDGE_MODEL = "openai/gpt-4o"
ANSWERS_FILE = "answers_v2.json"
JUDGE_FILE = "judgements_v2.json"

qa = {q["question_id"]: q for q in json.load(open("QA_06072026.json"))}

JUDGE_SYSTEM = (
    "You are a strict, fair grader for a question-answering benchmark. "
    "You are given a QUESTION, the REFERENCE ANSWER (ground truth, including the correct short answer "
    "and the reasoning), and a CANDIDATE ANSWER produced by a model. "
    "Decide whether the candidate's FINAL answer is correct.\n\n"
    "Rules:\n"
    "- Judge correctness of the substantive final answer, not writing style or verbosity.\n"
    "- The candidate need not match the reference wording; it must match the correct facts/number/conclusion.\n"
    "- For numeric answers, the final number must equal the reference short answer (allow trivial formatting differences).\n"
    "- If the candidate hedges or gives multiple answers without committing, treat the committed FINAL ANSWER line as its answer; if none, judge the overall conclusion.\n"
    "- 'partially_correct' = right direction / some required components correct but the final answer is wrong or incomplete.\n\n"
    "Respond with ONLY a JSON object (no markdown fences) of the form:\n"
    '{"verdict": "correct" | "incorrect" | "partially_correct", "score": <0.0-1.0>, "reason": "<one or two sentences>", "extracted_answer": "<the candidate\'s final answer>"}'
)

def make_judge_prompt(q, candidate):
    return (f"QUESTION ({q['question_category']}): {q['question']}\n\n"
            f"REFERENCE SHORT ANSWER: {q['short_answer']}\n\n"
            f"REFERENCE FULL ANSWER / REASONING:\n{q['answer']}\n\n"
            f"REFERENCE REMARKS (grader notes): {q.get('remarks') or ''}\n\n"
            f"==================== CANDIDATE ANSWER ====================\n{candidate}\n"
            f"=========================================================\n\n"
            f"Grade the candidate now. Output only the JSON object.")

def call_judge(prompt, retries=4):
    body = json.dumps({"model": JUDGE_MODEL, "messages": [
        {"role": "system", "content": JUDGE_SYSTEM}, {"role": "user", "content": prompt}],
        "temperature": 0, "max_tokens": 800, "response_format": {"type": "json_object"}}).encode()
    last = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(URL, body, {
                "Authorization": f"Bearer {KEY}", "Content-Type": "application/json",
                "HTTP-Referer": "https://localhost/qa-eval", "X-Title": "QA Eval Judge v2"})
            with urllib.request.urlopen(req, timeout=180) as r:
                d = json.load(r)
            return d["choices"][0]["message"].get("content") or ""
        except urllib.error.HTTPError as e:
            last = f"HTTP {e.code}: {e.read().decode(errors='replace')[:200]}"
            if e.code in (429, 500, 502, 503, 520, 524): time.sleep(2**attempt + 1); continue
            break
        except Exception as e:
            last = f"{type(e).__name__}: {e}"; time.sleep(2**attempt + 1)
    return f"__ERROR__ {last}"

def parse_judge(text):
    if text.startswith("__ERROR__"): return {"ok": False, "error": text}
    m = re.search(r"\{.*\}", text, re.S)
    if not m: return {"ok": False, "error": "no json", "raw": text[:300]}
    try:
        obj = json.loads(m.group(0))
        v = str(obj.get("verdict", "")).lower()
        if v not in ("correct", "incorrect", "partially_correct"): v = "incorrect"
        return {"ok": True, "verdict": v,
                "score": float(obj.get("score", 1.0 if v == "correct" else 0.0)),
                "reason": obj.get("reason", ""), "extracted_answer": obj.get("extracted_answer", "")}
    except Exception as e:
        return {"ok": False, "error": f"parse: {e}", "raw": text[:300]}

def main():
    answers = json.load(open(ANSWERS_FILE))
    judged = json.load(open(JUDGE_FILE)) if os.path.exists(JUDGE_FILE) else {}
    tasks = []
    for k, a in answers.items():
        if not a.get("ok"): continue
        if k in judged and judged[k].get("ok"): continue
        tasks.append((k, make_judge_prompt(qa[a["question_id"]], a["content"])))
    print(f"Pending judgements: {len(tasks)} (done: {sum(1 for v in judged.values() if v.get('ok'))})")
    done = [0]; last_save = [time.time()]
    def run(t):
        k, prompt = t; return k, parse_judge(call_judge(prompt))
    with ThreadPoolExecutor(max_workers=6) as ex:
        futs = [ex.submit(run, t) for t in tasks]
        for fut in as_completed(futs):
            k, res = fut.result(); judged[k] = res; done[0] += 1
            tag = res.get("verdict", "ERR") if res.get("ok") else "FAIL"
            print(f"[{done[0]}/{len(tasks)}] {k[:52]:52} -> {tag}")
            if time.time() - last_save[0] > 5 or done[0] == len(tasks):
                json.dump(judged, open(JUDGE_FILE, "w"), ensure_ascii=False); last_save[0] = time.time()
    json.dump(judged, open(JUDGE_FILE, "w"), ensure_ascii=False)
    ok = sum(1 for v in judged.values() if v.get("ok"))
    print(f"\nDone judging. ok={ok} fail={len(judged)-ok}")

if __name__ == "__main__":
    main()
